# vis-blueprint

Corrected system-directive-protocol visual infographic for 0sXai / ce-rd-os.
Produced from the garbled `Protocol_Blue_Print_ARCHIVE_ARTIFACT.png` source.

Read `AGENTS.md` first. It contains governance, the full task queue, and
file paths for all source material on disk.

## Contents

- [`AGENTS.md`](AGENTS.md) -- governance root, task queue, Zero Assumption Mandate
- [`HANDOFF_2026-04-29_vis-blueprint.md`](HANDOFF_2026-04-29_vis-blueprint.md) -- prior session state and decisions
- [`VIS_01_system_directive_blueprint_v02.html`](VIS_01_system_directive_blueprint_v02.html) -- corrected blueprint (editable source)
- [`PROMPT_system_directive_authoring_v01.md`](PROMPT_system_directive_authoring_v01.md) -- canonical text source, 15/15 Trinity gate

## Quick start for Opus agent

1. Drop this unzipped folder into Claude Projects or Claude Code working directory.
2. Agent reads `AGENTS.md` at session start.
3. First task: render `VIS_01_system_directive_blueprint_v02.html` to PNG
   via Puppeteer and present to Sage for visual QA.
4. Follow the priority task queue in `AGENTS.md` from there.

## Provenance

Prior session: Cowork mode, claude-sonnet-4-6, 2026-04-29.
Orchestrator: Sage (Austin B. Green).
Source PNG: `Protocol_Blue_Print_ARCHIVE_ARTIFACT.png` (OCR-garbled).
Canonical text source: `PROMPT_system_directive_authoring_v01.md` (15/15).

## License

CC-BY-4.0. Attribution: 0SxD.
