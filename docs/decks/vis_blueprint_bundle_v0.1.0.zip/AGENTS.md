# AGENTS.md

Conforms to the AGENTS.md standard at https://agents.md.
Read this file before any other. Address Sage only. No em dashes. No en dashes.

## Project overview

This bundle is the handoff for the `vis-blueprint` workstream.
The goal is a corrected, publishable set of visual system-directive images
for the 0sXai / ce-rd-os project, starting from a single source-of-truth HTML
file and exporting high-resolution PNGs for use as system-prompt images and
public-facing documentation.

The original PNG (`Protocol_Blue_Print_ARCHIVE_ARTIFACT.png`) contained
OCR-garbled and hallucinated text throughout all five sections. A corrected
HTML version (`VIS_01_system_directive_blueprint_v02.html`) was produced in
the prior session. That file is the canonical editable source going forward.
The PROMPT file (`PROMPT_system_directive_authoring_v01.md`) is the
authoritative text source for all labels and body copy.

## Architecture

```
vis-blueprint-bundle-v0.1.0/          (flat -- no subdirectories)
  AGENTS.md                           this file (governance root)
  README.md                           short TOC
  HANDOFF_2026-04-29_vis-blueprint.md session handoff with full state
  VIS_01_system_directive_blueprint_v02.html   corrected blueprint (editable source)
  PROMPT_system_directive_authoring_v01.md     canonical text source, 15/15 Trinity gate
```

All files are at root. No subdirectories. Drag the unzipped folder into
Claude Projects, NotebookLM, or any AGENTS.md-aware coding agent and begin.

## What was completed in the prior session

1. Read all source files in
   `C:\Users\Austin.DESKTOP-8AMMKQP\Downloads\SandBoxSetup\Visual_Prompts_Infographics_Revisions\`.
2. Identified 10+ tracked corrections (P1/P2/P3 severity) between the
   archive PNG and canonical prose.
3. Produced `VIS_01_system_directive_blueprint_v02.html`: a self-contained
   dark-theme HTML infographic with corrected text, inline SVG Trinity
   Dialectic diagram, octopus SVG, color-coded episodic loop, quarantine
   flow, and Trinity of Trinities 3x3 table. Saved to the
   `Visual_Prompts_Infographics_Revisions` directory.
4. Naming decision locked: use `0sXai` for project name,
   `system_directive_protocol` for protocol name (no `143` custom identifiers
   in user-facing output).

## What the next Opus agent session must do

Priority order (do not reorder without Sage approval):

1. RENDER TO PNG -- Open `VIS_01_system_directive_blueprint_v02.html` in
   headless Chrome via Puppeteer MCP or `npx puppeteer` and export a
   full-page PNG at 960px width. Save as
   `VIS_01_system_directive_blueprint_v02.png` to
   `Visual_Prompts_Infographics_Revisions\`.
   Install command if not present:
   `claude mcp add puppeteer npx -y @modelcontextprotocol/server-puppeteer`

2. VISUAL QA -- Open the PNG and compare it section by section to
   `Protocol_Blue_Print_ARCHIVE_ARTIFACT.png`. Confirm all five sections
   render correctly. Flag any layout breaks or text overflow to Sage before
   continuing.

3. SECTION BREAKOUTS -- Once the full-page PNG passes QA, produce five
   standalone HTML files, one per section:
   `VIS_01_s1_identity_v02.html` through `VIS_01_s5_trinity_v02.html`.
   Each file renders a single section at full width, suitable for export as
   a standalone PNG.

4. STYLE ITERATION -- Sage will provide specific visual corrections after
   seeing the rendered PNG. Do not refactor the HTML structure until Sage
   reviews the rendered output.

5. MANIFEST UPDATE -- Append one row per new file to
   `Visual_Prompts_Infographics_Revisions\MANIFEST.md` on completion of
   each deliverable.

## Source files on disk (do not assume -- verify before using)

All relative to
`C:\Users\Austin.DESKTOP-8AMMKQP\Downloads\SandBoxSetup\Visual_Prompts_Infographics_Revisions\`:

| File | Role |
|---|---|
| `Protocol_Blue_Print_ARCHIVE_ARTIFACT.png` | Original garbled PNG (layout reference only) |
| `VIS_01_system_directive_blueprint_v02.html` | Corrected editable source (THIS SESSION OUTPUT) |
| `PROMPT_system_directive_authoring_v01.md` | Canonical text source (15/15 Trinity gate) |
| `VIS_protocol_blueprint_v01.mmd` | Mermaid source (prior session, render-blocked) |
| `VIS_protocol_blueprint_v01.svg` | Mermaid-rendered SVG (prior session, minimal style) |
| `VIS_protocol_blueprint_text_equivalent_v01.md` | Tracked corrections table (10 entries) |
| `COORDINATION_README.md` | Workstream coordination and locked decisions |
| `MANIFEST.md` | Session manifest (append new rows per deliverable) |

Subfolders also present:
- `system_directive_layers_components\` -- five section-layer PNGs from
  prior NotebookLM export (use as section layout reference).
- `System_Protocol_Directive_Overview_wireframe_mockup1\` -- wireframe HTML
  project bundle from claude.ai/design (React source + standalone HTMLs).

## Zero Assumption Mandate

Do not assume project descriptions, repositories, or documents are correct.
Rely exclusively on accessible files and approved sources. If any file
referenced above is missing, flag to Sage and pause before continuing.

## Confidence loop

Before any execution, evaluate whether you have 100% of the context needed.
If below 100%, issue exactly three questions to Sage grouped as:
1. Architecture and State
2. Evidence and Sourcing
3. Intent and Constraint

Do not proceed until all three categories resolve.

## Trinity Dialectic gate

Before finalizing any output:
- Logos 0-5: logically consistent, sources cited, shortest path taken
- Pathos 0-5: aligned with purpose, no wasted steps
- Ethos 0-5: constraints met, executable, arbitrated

Sum must reach 15 to PROCEED. Below 15, loop back and issue three questions.

## No em dash rule

No em dashes (U+2014) and no en dashes (U+2013) in any output or artifact.
Use hyphens, commas, or line breaks.

## License

CC-BY-4.0. Attribution: 0SxD.

END_AGENTS_MD
